# import os
#
command = "java -cp /Users/brillianthc/.m2/repository/junit/junit/4.11/junit-4.11.jar:/Users/brillianthc/.m2/repository/org/hamcrest/hamcrest-core/1.3/hamcrest-core-1.3.jar:. org.junit.runner.JUnitCore com.junit.calculatetest com.junit.calculatetest2"
# os.system(command)

from subprocess import Popen, PIPE

stdout = Popen(command, shell=True, stdout=PIPE).stdout
output = stdout.read()

def check_result(output):
    if("OK" in str(output)):
        list = str(output).split(" ")
        # print(list[-2])
        # print([int(i) for i in list[-2].split("(") if i.isdigit()][0])
        success_times = [int(i) for i in list[-2].split("(") if i.isdigit()][0]
        failure_times = 0


    else:

        list = str(output).split(" ")
        print(list[-4:])
        total = list[-4][0]
        print(total)
        failure_times = [int(i) for i in list[-1].split("\\") if i.isdigit()][0]
        print(failure_times)
        success_times = int(total) - failure_times

        print(success_times)

    return success_times, failure_times

print(check_result(output))